<?php include_once('modele/conect.php') ;
function check($u , $p) {
     $sql = "select * from user_ord where userName='$u' and pwd='$p'" ;
     $res = read($sql) ; 
     if(count($res)==0){
          echo"<script>
          alert('echec') ;
          </script>";
     }else{
          include_once("view/login.php") ;
     }

}
?>