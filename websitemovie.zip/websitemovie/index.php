<?php 
include_once('controlleur/actions.php');
if(!isset($_GET['action']))
{
     require_once('view/home.php') ;
}
else
switch($_GET['action'])
{
     case 'auth'  : $u = $_POST['uname'] ;
                    $p = $_POST['psw'] ;
                    check($u , $p);
                    break ; 
}
?>