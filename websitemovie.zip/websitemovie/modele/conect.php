<?php
function conecter(){
$con = new PDO("mysql:host=localhost;dbname=movietime","root" ,"") ;
return $con ;

}
function read($sql){
     $t = conecter()->query($sql)->fetchAll(PDO::FETCH_NUM) ; 
     return $t ;
}
?>