<!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        


        <!--========== BOX ICONS ==========-->
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/boxicons@latest/css/boxicons.min.css">

        <!--========== CSS ==========-->
        <link rel="stylesheet" href="view/assets/css/styles.css">
        

        <title>Movietime</title>
        <link rel="icon" href="assets/img/icons8-film-reel-50.png">

    </head>
    <body>
        <!--========== HEADER ==========-->
        <header class="header">
            <div class="header__container">
                
                 
                <!-- <div class="header__login">
                     <input  onclick="document.getElementById('id02').style.display='block'" class="header_btn" type="button" value="Register" /> 
                      <input onclick="document.getElementById('id01').style.display='block'" class="header_btn" name="login" type="button" value="Login" /> 
                </div> 
                Login form
                <div id="id01" class="modal">
  
                    <form class="modal-content animate" action="?action=auth" method="post">
                      <div class="imgcontainer">
                        <span onclick="document.getElementById('id01').style.display='none'" class="close" title="Close Modal">&times;</span>
                        <h1>Sign In</h1>
                      </div>
                  
                      <div class="container">
                        <label for="uname"><b>Username</b></label>
                        <input type="text"  name="uname" required>
                  
                        <label for="psw"><b>Password</b></label>
                        <input type="password"  name="psw" required>
                          
                        <button class="blr" type="submit">Login</button>
                        <label>
                          <input type="checkbox" checked="checked" name="remember"> Remember me
                        </label>
                          <span class="psw"><a href="#"> Forgot password?</a></span>
                      </div>
                  
                      <h5>Don't have an account? <a  href=""> Sign up here!</a> </h5>
                    
                    </form>
                   
                  </div> 
                  
                   Resister form
                  <div id="id02" class="modal" >
  
                    <form class="modal-content animate" action="" method="">
                      <div class="imgcontainer">
                        <span onclick="document.getElementById('id02').style.display='none'" class="close" title="Close Modal">&times;</span>
                        <h1>Create account</h1>
                      </div>
                  
                      <div class="container">
                        <label for="uname"><b>Username</b></label>
                        <input type="text"  name="uname" required>
                  
                        <label for="psw"><b>Email</b></label>
                        <input type="password"  name="psw" required>

                        <label for="psw"><b>Password </b></label>
                        <input type="password" placeholder="at least 8 charcters" name="psw" required>

                        <label for="psw"><b>Password Confirm</b></label>
                        <input type="password"  name="psw" required>

                        
                          
                        <button class="blr" type="submit">Sign Up</button>
                        
                      </div>
                  
                      
                   
                    </form>
                  </div> 
                -->
               
                  

                <a href="#" class="header__logo">Movie<span class="col">time</span> </a>
    
                 <div class="header__search">
                    <input type="search" placeholder="Search" class="header__input">
                    <i class='bx bx-search header__icon'></i>
                </div>
    
                <div class="header__toggle">
                    <i class='bx bx-menu' id="header-toggle"></i>
                </div>
            </div>
        </header> 
        <!--========== NAV ==========-->
        <div class="nav" id="navbar">
            <nav class="nav__container">
                <div>
                    <a href="#" class="nav__link nav__logo">
                        <i class='bx bxs-disc nav__icon' ></i>
                        <span class="nav__logo-name">Movie<span class="col">time</span></span>
                    </a>
    
                    <div class="nav__list">
                        <div class="nav__items">
                            <h3 class="nav__subtitle">Discover</h3>
    
                            
                            <div class="nav__dropdown">
                                <a href="#" class="nav__link">
                                    <i class='bx bx-camera-movie nav__icon' ></i>
                                    <span class="nav__name">Movies</span>
                                    <i class='bx bx-chevron-down nav__icon nav__dropdown-icon'></i>
                                </a>

                                <div class="nav__dropdown-collapse">
                                    <div class="nav__dropdown-content">
                                        <a href="#" class="nav__dropdown-item">Popular</a>
                                        <a href="#" class="nav__dropdown-item">Upcoming</a>
                                        <a href="#" class="nav__dropdown-item">Top Reted</a>
                                    </div>
                                </div>
                            </div>

                            <div class="nav__dropdown">
                                <a href="#" class="nav__link">
                                    <i class='bx bx-tv nav__icon' ></i>
                                    <span class="nav__name">TV Shows</span>
                                    <i class='bx bx-chevron-down nav__icon nav__dropdown-icon'></i>
                                </a>

                                <div class="nav__dropdown-collapse">
                                    <div class="nav__dropdown-content">
                                        <a href="#" class="nav__dropdown-item">Popular</a>
                                        <a href="#" class="nav__dropdown-item">On TV</a>
                                        <a href="#" class="nav__dropdown-item">Top Reted</a>
                                    </div>
                                </div>
                            </div>

                            
                            <div class="nav__dropdown">
                                <a href="#" class="nav__link">
                                    <i class='bx bx-face nav__icon' ></i>
                                    <span class="nav__name">People</span>
                                    <i class='bx bx-chevron-down nav__icon nav__dropdown-icon'></i>
                                </a>

                                <div class="nav__dropdown-collapse">
                                    <div class="nav__dropdown-content">
                                        <a href="#" class="nav__dropdown-item">Popular People</a>
                                    </div>
                                </div>
                            </div>

                            <a href="#" class="nav__link">
                                <i class='bx bx-group nav__icon' ></i>
                                <span class="nav__name">Community</span>
                            </a>
                        </div>
    
                        <div class="nav__items">
                            <h3 class="nav__subtitle">Manage</h3>
    
                            

                            <a href="#" class="nav__link">
                                
                                <i class='bx bx-list-ul nav__icon' ></i>
                                <span class="nav__name">Lists</span>
                            </a>
                            <a href="#" class="nav__link">
                                <i class='bx bx-heart nav__icon' ></i>
                                <span class="nav__name">Favorite</span>
                            </a>
                            <a href="#" class="nav__link">
                                <i class='bx bx-bookmark nav__icon' ></i>
                                <span class="nav__name">Watchlist</span>
                            </a>
                            <a href="#" class="nav__link">
                                <i class='bx bx-star nav__icon' ></i>
                                <span class="nav__name">Rate</span>
                            </a>
                        </div>
                    </div>
                </div>

                <a href="#" class="nav__link nav__logout">
                    <i class='bx bx-customize nav__icon' ></i>
                    <span class="nav__name">Customize</span>
                </a>
                
            </nav>
        </div>

        <!--========== CONTENTS ==========-->
        <main>
            <section>
            </section>
        </main>

        <!--========== MAIN JS ==========-->
        

        <script>

// Get the modal
var modal1 = document.getElementById('id01');
var modal2 = document.getElementById('id02');

// When the user clicks anywhere outside of the modal, close it
window.onclick = function(event) {
    if (event.target == modal1 ) {
        modal1.style.display = "none";
        
    }

    if (event.target == modal2 ) {
        modal2.style.display = "none";
        
    }
}


</script>



    </body>
</html>